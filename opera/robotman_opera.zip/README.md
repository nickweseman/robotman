# Robotman: a game inspired by flappy bird, but with ROBOTS!

## Google Chrome

### Installation from Google Chrome Web Store Instructions:
1.  Visit: https://chrome.google.com/webstore/detail/robotman/cjpdlmjbocfbhjgdpmfkcphkacmighmb?hl=en-US&gl=US to install.

### Installation from Source Instructions:
1. Download "robotman" folder to your computer
2. Open Chrome and type "chrome://extensions" into the browser url
3. Make sure that the "Developer mode" checkbox is checked.
4. Click "Load unpacked extension..."
5. Select the "robotman" folder you chose above.

### To Play:
1.  Click "Robotman" icon at top right of the browser.

<br>
<br>

## Opera

Coming Soon

<br>
<br>

## Firefox

Coming Soon

<br>
<br>

Icons made by Lorc. Available on http://game-icons.net
<br>
Background created by Freepik
